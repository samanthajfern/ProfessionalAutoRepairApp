//
//  ViewController.swift
//  ProfessionalAutoRepair
//
//  Created by debosmebo on 11/20/20.
//  Copyright © 2020 debosmebo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func signin(_ sender: UIButton) {
        
//        let vc = SigninViewController()
//        
//        vc.modalPresentationStyle = .fullScreen
//        
//        self.present(vc,animated:true,completion: nil)
    }
    
}

