//
//  CreateApptViewController.swift
//  ProfessionalAutoRepair
//
//  Created by debosmebo on 12/11/20.
//  Copyright © 2020 debosmebo. All rights reserved.
//

import UIKit

class CreateApptViewController: UIViewController {
    


    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        processApi()
    }
    func processApi(){
    

        let headers = [
            "x-rapidapi-key": "5161897816mshd80784a6ecf04fbp17aeeajsn2d8bdef213ba",
            "x-rapidapi-host": "cis-vin-decoder.p.rapidapi.com",
            "content-type":"application/json"
        ]
        
        let vin = "5J6RM4H50GL105806"
    
        let request = NSMutableURLRequest(url: NSURL(string: "https://cis-vin-decoder.p.rapidapi.com/vinDecode?vin=\(vin)")! as URL,
                                                cachePolicy: .useProtocolCachePolicy,
                                            timeoutInterval: 10.0)
        request.httpMethod = "GET"
        request.allHTTPHeaderFields = headers
    
        let session = URLSession.shared
        let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
            if (error != nil) {
                print(error)
            } else {
                let httpResponse = response as? HTTPURLResponse
               
                do{
                    
                    let json = try JSONSerialization.jsonObject(with:data!,options:[]) as? [String:Any]
                    for (key,_) in json!{
                        if let nestedDictionary = json![key] as? [String:Any]{
                            
                            print(nestedDictionary.keys)
                            
                            // list of keys for future upgrades to the app
                            
                            /*["Doors", "DisplacementCI", "VehicleType", "PlantState", "BodyClass", "GVWR", "EngineCylinders", "DisplacementL", "DisplacementCC", "EngineKW", "Model", "AirBagLocSide", "PlantCountry", "TransmissionStyle", "Series", "AirBagLocFront", "Make", "FuelTypePrimary", "TPMS", "EngineConfiguration", "VIN", "RecallInfo", "PlantCity", "Manufacturer", "EngineHP", "EngineModel", "ModelYear", "OtherRestraintSystemInfo", "ValveTrainDesign", "DriveType", "ManufacturerId", "SeatBeltsAll", "AirBagLocCurtain"]*/
                            
                            print(nestedDictionary["Make"]!)
                            print(nestedDictionary["Model"]!)
                            print(nestedDictionary["ModelYear"]!)
                            
                        }
                    }
                    

                }
                catch{
                    print("failed to convert to json \(error)")
                }

            }
        })
    
        dataTask.resume()
    }

}
