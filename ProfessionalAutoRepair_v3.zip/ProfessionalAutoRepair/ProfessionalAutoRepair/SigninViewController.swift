//
//  SigninViewController.swift
//  ProfessionalAutoRepair
//
//  Created by debosmebo on 11/21/20.
//  Copyright © 2020 debosmebo. All rights reserved.
//

import UIKit

class SigninViewController: UIViewController {
    
    
    @IBOutlet var username: UITextField!
    
    @IBOutlet var password: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func onLoginClick(_ sender: UIButton) {
        
        // need authentication here
        
        if let tabbarcontroller = (storyboard?.instantiateViewController(withIdentifier: "tabbarcontroller") as? UITabBarController){
            tabbarcontroller.modalPresentationStyle = .fullScreen
            navigationController?.pushViewController(tabbarcontroller, animated: true)
        
        //self.present(tabbarcontroller, animated: true, completion: nil)
        }
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
