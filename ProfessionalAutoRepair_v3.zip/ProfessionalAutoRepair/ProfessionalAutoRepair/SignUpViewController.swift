//
//  SignUpViewController.swift
//  ProfessionalAutoRepair
//
//  Created by debosmebo on 12/9/20.
//  Copyright © 2020 debosmebo. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController {
    
    
    @IBOutlet var first: UITextField!
    
    @IBOutlet var last: UITextField!
    
    @IBOutlet var email: UITextField!
    
    @IBOutlet var password: UITextField!
    
    let db = LocalDatabase.instance.firebaseDatabase
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func onJoinClick(_ sender: UIButton) {
        
        var first = "Lebron"
        
        db.child("Users/\(first)").setValue(["first":first,
                                     "last":"James",
                                     "role":"admin",
                                     "email":"kingjames@gmail.com",
                                     "password":"12345678"])
        
        
        db.child("Users/\(first)").observeSingleEvent(of:.value,with:{snapshot in

            guard let value = snapshot.value as? [String: Any] else{

                return
            }

            print(value["role"] as! String)
        })
        

        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
