//
//  database.swift
//  ProfessionalAutoRepair
//
//  Created by debosmebo on 11/20/20.
//  Copyright © 2020 debosmebo. All rights reserved.
//

import Foundation
import FirebaseDatabase
//import Firebase
//import FirebaseAuth

class LocalDatabase{

static let instance = LocalDatabase()

private init(){}
    
    let firebaseDatabase = Database.database().reference()
    
    
   

}
